// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable UnusedType.Global
// ReSharper disable UnusedMember.Local
// ReSharper disable UnusedMember.Global
// ReSharper disable ClassNeverInstantiated.Global

using System.Diagnostics.CodeAnalysis;

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

namespace EventUnion.Domain.Events;

public class Tag
{
    public Guid TagId { get; private set; }
    public string Name { get; private set; }
    public decimal Value { get; private set; }
    
    public Event Event { get; private set; }

    public Tag(Guid tagId, Event eventAttr, string name, decimal value)
    {
        TagId = tagId;
        Event = eventAttr;
        Name = name;
        Value = value;
    }

    [ExcludeFromCodeCoverage]
    private Tag() { }
}