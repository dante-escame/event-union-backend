// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable UnusedType.Global
// ReSharper disable UnusedMember.Local
// ReSharper disable UnusedMember.Global
// ReSharper disable ClassNeverInstantiated.Global

using System.Diagnostics.CodeAnalysis;

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

namespace EventUnion.Domain.Events;

public class Target
{
    public Guid TargetId { get; private set; }
    public string Description { get; private set; }

    public Target(Guid targetId, string description)
    {
        TargetId = targetId;
        Description = description;
    }

    [ExcludeFromCodeCoverage]
    private Target() { }
}