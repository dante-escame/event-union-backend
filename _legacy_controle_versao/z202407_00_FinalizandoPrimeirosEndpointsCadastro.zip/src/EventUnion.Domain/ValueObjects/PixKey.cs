using System.Diagnostics.CodeAnalysis;
using CSharpFunctionalExtensions;
using EventUnion.CommonResources;

namespace EventUnion.Domain.ValueObjects;

public class PixKey : ValueObject
{
    // ReSharper disable once AutoPropertyCanBeMadeGetOnly.Local
    public string Value { get; private set; } = null!;
    // ReSharper disable once AutoPropertyCanBeMadeGetOnly.Local
    // ReSharper disable once MemberCanBePrivate.Global
    public PixKeyType Type { get; private set; }

    // ReSharper disable once UnusedMember.Global
    public string FormattedValue => FormatValue(Value, Type);

    // ReSharper disable once UnusedMember.Global
    public static Result<PixKey, Error> Create(string pixKey, PixKeyType type, string fieldName = "PixKey")
    {
        if (string.IsNullOrWhiteSpace(pixKey)) return CommonError.ValueIsEmpty(fieldName);
        
        var validationResult = Validate(pixKey, type);

        if (validationResult.IsFailure) return validationResult.Error;

        pixKey = Sanitize(pixKey, type);

        return new PixKey(pixKey, type);
    }
    
    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Value;
        yield return Type;
    }

    private static string Sanitize(string pixKey, PixKeyType type)
    {
        return type switch
        {
            PixKeyType.Cpf => Cpf.Sanitize(pixKey),
            PixKeyType.Cnpj => Cnpj.Sanitize(pixKey),
            PixKeyType.Email => Email.Sanitize(pixKey),
            PixKeyType.PhoneNumber => PhoneNumber.Sanitize(pixKey),
            PixKeyType.Random => SanitizeRandomPixKey(pixKey),
            _ => throw new ArgumentOutOfRangeException(nameof(type), type, null)
        };
    }

    private static string SanitizeRandomPixKey(string pixKey) => StringUtils.RemoveExtraSpaces(pixKey);

    private static UnitResult<Error> Validate(string pixKey, PixKeyType type, string fieldName = "PixKey")
    {
        switch (type)
        {
            case PixKeyType.Cpf:
                var cpfResult = Cpf.Create(pixKey, fieldName);
                return cpfResult.IsSuccess 
                    ? UnitResult.Success<Error>() 
                    : cpfResult.Error;

            case PixKeyType.Cnpj:
                var cnpjResult = Cnpj.Create(pixKey, fieldName);
                return cnpjResult.IsSuccess 
                    ? UnitResult.Success<Error>() 
                    : cnpjResult.Error;

            case PixKeyType.Email:
                var emailResult = Email.Create(pixKey, fieldName);
                return emailResult.IsSuccess 
                    ? UnitResult.Success<Error>() 
                    : emailResult.Error;

            case PixKeyType.PhoneNumber:
                var phoneNumberResult = PhoneNumber.Create(pixKey, fieldName);
                return phoneNumberResult.IsSuccess
                    ? UnitResult.Success<Error>() 
                    : phoneNumberResult.Error;

            case PixKeyType.Random:
                return IsValidRandomPix(pixKey)
                    ? UnitResult.Success<Error>()
                    : CommonError.ValueIsInvalid(fieldName);

            default:
                return CommonError.ValueIsInvalid("PixKey.Type");
        }
    }

    private static bool IsValidRandomPix(string pixKey)
    {
        var treatedValue = StringUtils.RemoveNonAlphaNumericChars(pixKey);
        return treatedValue.Length == 32 && treatedValue.All(char.IsLetterOrDigit);
    }

    private static string FormatValue(string value, PixKeyType type)
    {
        return type switch
        {
            PixKeyType.Cpf => StringUtils.FormatCpf(value),
            PixKeyType.Cnpj => StringUtils.FormatCnpj(value),
            PixKeyType.PhoneNumber => PhoneNumber.FormatPhoneNumber(value),
            PixKeyType.Email => value,
            PixKeyType.Random => value,
            _ => throw new ArgumentException("O valor 'PixKey.Type' é inválido.")
        };
    }

    private PixKey(string value, PixKeyType type)
    {
        Value = value;
        Type = type;
    }
    
    // EFCore Constructor
    // ReSharper disable once UnusedMember.Local
    [ExcludeFromCodeCoverage]
    private PixKey() { }
}

public enum PixKeyType
{
    Cpf = 0,
    Cnpj = 1,
    Email = 2,
    PhoneNumber = 3,
    Random = 4
}
