using System.Diagnostics.CodeAnalysis;
using CSharpFunctionalExtensions;
using EventUnion.CommonResources;

namespace EventUnion.Domain.ValueObjects;

public class Url : ValueObject
{
    // ReSharper disable once AutoPropertyCanBeMadeGetOnly.Local
    public string Value { get; private set; } = null!;
    
    public static Result<Url, Error> Create(string url, string fieldName = "Url")
    {
        if (string.IsNullOrWhiteSpace(url))
            return CommonError.ValueIsEmpty(fieldName);
        
        url = StringUtils.RemoveExtraSpaces(url).ToLower();

        if (!ContainsProtocol(url))
            return CommonError.ValueIsInvalid(fieldName);
        
        if (!ContainsOnlyValidCharacters(url))
            return CommonError.ValueIsInvalid(fieldName);

        return new Url(url);
    }
    
    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Value;
    }
    
    private static readonly char[] AllowedSpecialChars = ['-', '_', '.', '/'];
    private const string HttpsProtocol = "https://";
    private const string HttpProtocol = "http://";
    
    private static bool IsHttps(string url) => url.StartsWith(HttpsProtocol);
    
    private static bool IsHttp(string url) => url.StartsWith(HttpProtocol);
    
    public static bool ContainsProtocol(string url) => IsHttps(url) || IsHttp(url);
    
    private static bool ContainsOnlyValidCharacters(string url)
    {
        var urlWithoutProtocol = RemoveProtocol(url);
        
        return urlWithoutProtocol.All(c => char.IsLetterOrDigit(c) || AllowedSpecialChars.Contains(c));
    }

    private static string RemoveProtocol(string url) 
        => url.Replace(IsHttps(url) ? HttpsProtocol : HttpProtocol, "");
    
    private Url(string value)
    {
        Value = value;
    }
    
    // EFCore Constructor
    // ReSharper disable once UnusedMember.Local
    [ExcludeFromCodeCoverage]
    private Url() { }
}