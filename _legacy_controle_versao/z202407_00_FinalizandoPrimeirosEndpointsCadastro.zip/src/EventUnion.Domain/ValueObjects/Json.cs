using System.Diagnostics.CodeAnalysis;
using CSharpFunctionalExtensions;
using EventUnion.CommonResources;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace EventUnion.Domain.ValueObjects;

public class Json : ValueObject
{
    // ReSharper disable once AutoPropertyCanBeMadeGetOnly.Local
    // ReSharper disable once MemberCanBePrivate.Global
    public string Value { get; private set; } = null!;

    // ReSharper disable once UnusedMember.Global
    public string FormattedValue => FormatJson(Value);

    // ReSharper disable once UnusedMember.Global
    public static Result<Json, Error> Create(string json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return CommonError.ValueIsEmpty("Json");

        if (!IsValidJson(json))
            return CommonError.ValueIsInvalid("Json");

        var minifiedJson = MinifyJson(json);

        return new Json(minifiedJson);
    }

    private static bool IsValidJson(string json)
    {
        try
        {
            var parsedJson = JToken.Parse(json);
            return parsedJson.Type is JTokenType.Object or JTokenType.Array;
        }
        catch (JsonReaderException)
        {
            return false;
        }
    }

    private static string FormatJson(string json)
    {
        var parsedJson = JToken.Parse(json);
        return parsedJson.ToString(Formatting.Indented);
    }

    private static string MinifyJson(string json)
    {
        var parsedJson = JToken.Parse(json);
        return parsedJson.ToString(Formatting.None);
    }
    
    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Value;
    }

    private Json(string value)
    {
        Value = value;
    }
    
    // EFCore Constructor
    // ReSharper disable once UnusedMember.Local
    [ExcludeFromCodeCoverage]
    // ReSharper disable once UnusedMember.Local
    private Json() { }
}