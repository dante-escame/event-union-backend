using CSharpFunctionalExtensions;

namespace EventUnion.Domain.AutomaticTransfers;

public class DailyAutomaticTransfer : Entity<Guid>
{
    // ReSharper disable once UnusedMember.Local
    private DailyAutomaticTransfer() { }
}