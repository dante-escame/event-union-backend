using EventUnion.CommonResources.Interfaces;

namespace EventUnion.Domain.AutomaticTransfers.Processes;

// ReSharper disable once ClassNeverInstantiated.Global
public sealed record AutomaticTransferProcessedDomainEvent(
    Guid Id, 
    Guid ProcessId,
    Guid AutomaticTransferId
    ) : IDomainEvent;