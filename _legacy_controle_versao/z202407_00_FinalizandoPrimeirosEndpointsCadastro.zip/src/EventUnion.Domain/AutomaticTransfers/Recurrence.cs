using CSharpFunctionalExtensions;

namespace EventUnion.Domain.AutomaticTransfers;

public class Recurrence : Entity<int>
{
    // ReSharper disable once UnusedMember.Local
    private Recurrence() { }

    private Recurrence(int id, string name) : base(id)
    {
        Name = name;
    }

    public static readonly Recurrence Daily = new(1, "Daily Recurrence");
    public static readonly Recurrence Weekly = new(2, "Weekly Recurrence");
    public static readonly Recurrence Monthly = new(3, "Monthly Recurrence");

    public static readonly IReadOnlyList<Recurrence> AllRecurrenceTypes = [Daily, Weekly, Monthly];

    public string Name { get; private set; } = null!;
}