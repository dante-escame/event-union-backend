// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable UnusedType.Global
// ReSharper disable UnusedMember.Local
// ReSharper disable UnusedMember.Global

using System.Diagnostics.CodeAnalysis;
using EventUnion.Domain.IdentityContext;

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

namespace EventUnion.Domain.EventContext;

public class Event
{
    public Guid EventId { get; private set; }
    
    public string Name { get; private set; }
    public string Description { get; private set; }
    public DateTime StartDate { get; private set; }
    public DateTime EndDate { get; private set; }

    public User UserOwner { get; private set; }
    public EventType EventType { get; private set; }
    public Target Target { get; private set; }

    public Event(Guid eventId, User userOwner, EventType eventType, string name, string description, DateTime startDate, DateTime endDate, Target target)
    {
        EventId = eventId;
        UserOwner = userOwner;
        EventType = eventType;
        Name = name;
        Description = description;
        StartDate = startDate;
        EndDate = endDate;
        Target = target;
    }

    [ExcludeFromCodeCoverage]
    private Event() { }
}