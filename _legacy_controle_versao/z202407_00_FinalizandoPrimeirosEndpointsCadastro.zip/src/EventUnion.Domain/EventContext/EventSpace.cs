// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable UnusedType.Global
// ReSharper disable UnusedMember.Local
// ReSharper disable UnusedMember.Global
// ReSharper disable ClassNeverInstantiated.Global

using System.Diagnostics.CodeAnalysis;

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

namespace EventUnion.Domain.EventContext;

public class EventSpace
{
    public Guid EventSpaceId { get; private set; }
    public Event Event { get; private set; }
    public Place Place { get; private set; }
    public DateTime StartDate { get; private set; }
    public DateTime EndDate { get; private set; }

    public EventSpace(Guid eventSpaceId, Event eventObj, Place place, DateTime startDate, DateTime endDate)
    {
        EventSpaceId = eventSpaceId;
        Event = eventObj;
        Place = place;
        StartDate = startDate;
        EndDate = endDate;
    }

    [ExcludeFromCodeCoverage]
    private EventSpace() { }
}