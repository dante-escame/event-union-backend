// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable UnusedType.Global
// ReSharper disable UnusedMember.Local

using System.Diagnostics.CodeAnalysis;

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

namespace EventUnion.Domain.IdentityContext;

public class Interest
{
    public Guid InterestId { get; private set; }
    public User User { get; private set; }
    public string Name { get; private set; }

    public Interest(Guid interestId, User user, string name)
    {
        InterestId = interestId;
        User = user;
        Name = name;
    }
    
    [ExcludeFromCodeCoverage]
    private Interest() { }
}