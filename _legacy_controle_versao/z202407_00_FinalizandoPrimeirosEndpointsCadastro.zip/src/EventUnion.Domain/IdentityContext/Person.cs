// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable UnusedType.Global
// ReSharper disable UnusedMember.Local
#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

namespace EventUnion.Domain.IdentityContext;

public class Person : User
{
    public Guid PersonId { get; private set; }
    public string Name { get; private set; }
    public string Cpf { get; private set; }
    public DateTime Birthdate { get; private set; }

    public Person(Guid userId, string email, string password, string criptKey, string iv, 
        Guid personId, string name, string cpf, DateTime birthdate)
        : base(userId, email, password, criptKey, iv)
    {
        PersonId = personId;
        Name = name;
        Cpf = cpf;
        Birthdate = birthdate;
    }
}