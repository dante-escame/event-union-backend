using CSharpFunctionalExtensions;
using EventUnion.Api.Features.Common;
using EventUnion.CommonResources;
using EventUnion.Domain.Common.Interfaces;
using EventUnion.Domain.IdentityContext;
using FastEndpoints;
using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Authorization;
// ReSharper disable UnusedType.Global
// ReSharper disable UnusedAutoPropertyAccessor.Local

namespace EventUnion.Api.Features.Users;

public static class AddPerson
{
    #region Endpoint
    
    // ReSharper disable UnusedAutoPropertyAccessor.Global
    // ReSharper disable once ClassNeverInstantiated.Global
    public class Request
    {
        public UserPayload? User { get; set; }
        public string? Name { get; set; }
        public string? Cpf { get; set; }
        public DateTime Birthdate { get; set; }
        public List<string>? Interests { get; set; }

        public record UserPayload
        {
            public string? Email { get; set; }
            public string? Password { get; set; }
        }
    }
    // ReSharper restore UnusedAutoPropertyAccessor.Global

    public class RequestValidator : Validator<Request>
    {
        public RequestValidator()
        {
            RuleLevelCascadeMode = CascadeMode.Stop;

            RuleFor(x => x.Name)
                .NotNullWithError();
        }
    }

    // ReSharper disable once UnusedType.Global
    [Authorize]
    public class Endpoint(ISender sender) : Endpoint<Request, Result<ResourceLocator<Guid>, Error>>
    {
        public override void Configure()
        {
            Post("api/people");
        }
        
        public override async Task<Result<ResourceLocator<Guid>, Error>> ExecuteAsync(Request req, CancellationToken ct)
        {
            var commandSave = new Command(
                req.Name, req.Cpf, req.Birthdate, req.Interests, 
                req.User?.Email, req.User?.Password);
            
            return await sender.Send(commandSave, ct);
        }
    }
    #endregion
    
    #region Handler
    public record Command(
        string? Name, string? Cpf, DateTime? BirthDate, List<string>? Interests,
        string? Email, string? Password) : IRequest<Result<ResourceLocator<Guid>, Error>>;
    
    // ReSharper disable once UnusedType.Global
    internal class Handler(
        IUnitOfWork unitOfWork)
        : IRequestHandler<Command, Result<ResourceLocator<Guid>, Error>>
    {
        public async Task<Result<ResourceLocator<Guid>, Error>> Handle(Command request, CancellationToken ct)
        {
            var (pwd, key, iv) = EncryptionHelper.EncryptPassword(request.Password!);
            
            var person = new Person(Guid.NewGuid(), request.Email ?? "", pwd, key,
                iv, Guid.NewGuid(), request.Name ?? "", 
                request.Cpf ?? "", request.BirthDate!.Value);
            
            await unitOfWork.AddAsync(person, ct);

            foreach (var interestName in request.Interests ?? [])
            {
                var interest = new Interest(Guid.NewGuid(), person, interestName);
                
                await unitOfWork.AddAsync(interest, ct);
            }
            
            var result = await unitOfWork.SaveChangesAsync(ct);
            if (result.IsFailure)
                return result.Error;

            return new ResourceLocator<Guid>(person.UserId);
        }
    }
    #endregion
}