using CSharpFunctionalExtensions;
using EventUnion.Api.Features.Common;
using EventUnion.CommonResources;
using EventUnion.Domain.Common.Interfaces;
using EventUnion.Domain.IdentityContext;
using FastEndpoints;
using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Authorization;

// ReSharper disable UnusedType.Global
// ReSharper disable UnusedAutoPropertyAccessor.Local

namespace EventUnion.Api.Features.Users;

public static class AddCompany
{
    #region Endpoint
    
    // ReSharper disable UnusedAutoPropertyAccessor.Global
    public class Request
    {
        public UserPayload? User { get; set; }
        public string? LegalName { get; set; }
        public string? TradeName { get; set; }
        public string? Cnpj { get; set; }
        public string? Specialization { get; set; }
        public List<string>? Interests { get; set; }

        public record UserPayload
        {
            public string? Email { get; set; }
            public string? Password { get; set; }
        }
    }
    // ReSharper restore UnusedAutoPropertyAccessor.Global

    public class RequestValidator : Validator<Request>
    {
        public RequestValidator()
        {
            RuleLevelCascadeMode = CascadeMode.Stop;

            RuleFor(x => x.LegalName)
                .NotNullWithError();

            RuleFor(x => x.TradeName)
                .NotNullWithError();

            RuleFor(x => x.Cnpj)
                .NotNullWithError();

            RuleFor(x => x.Specialization)
                .NotNullWithError();
        }
    }

    [Authorize]
    public class Endpoint(ISender sender) : Endpoint<Request, Result<ResourceLocator<Guid>, Error>>
    {
        public override void Configure()
        {
            Post("api/companies");
        }
        
        public override async Task<Result<ResourceLocator<Guid>, Error>> ExecuteAsync(Request req, CancellationToken ct)
        {
            var commandSave = new Command(
                req.LegalName, req.TradeName, req.Cnpj, req.Specialization,
                req.Interests, req.User?.Email, req.User?.Password);
            
            return await sender.Send(commandSave, ct);
        }
    }
    #endregion
    
    #region Handler
    public record Command(
        string? LegalName, string? TradeName, string? Cnpj, string? Specialization,
        List<string>? Interests, string? Email, string? Password) : IRequest<Result<ResourceLocator<Guid>, Error>>;
    
    internal class Handler(
        IUnitOfWork unitOfWork)
        : IRequestHandler<Command, Result<ResourceLocator<Guid>, Error>>
    {
        public async Task<Result<ResourceLocator<Guid>, Error>> Handle(Command request, CancellationToken ct)
        {
            var (pwd, key, iv) = EncryptionHelper.EncryptPassword(request.Password!);
            
            var company = new Company(Guid.NewGuid(), request.Email ?? "", pwd, key,
                iv, Guid.NewGuid(), request.LegalName ?? "", 
                request.TradeName ?? "", request.Cnpj ?? "", request.Specialization ?? "");
            
            await unitOfWork.AddAsync(company, ct);

            foreach (var interestName in request.Interests ?? [])
            {
                var interest = new Interest(Guid.NewGuid(), company, interestName);
                
                await unitOfWork.AddAsync(interest, ct);
            }
            
            var result = await unitOfWork.SaveChangesAsync(ct);
            if (result.IsFailure)
                return result.Error;

            return new ResourceLocator<Guid>(company.UserId);
        }
    }
    #endregion
}