using EventUnion.Domain.AutomaticTransfers.Processes;

namespace EventUnion.Infrastructure.Repositories;

public class AutomaticTransferProcessRepository(EventUnionDbContext dbContext)
    : IAutomaticTransferProcessRepository
{
    public Task<List<AutomaticTransferProcess>> GetActiveAwaitingProcesses(DateTime now)
    {
        throw new NotImplementedException();
    }

    public Task<AutomaticTransferProcess?> GetByIdAsync(Guid automaticTransferProcessId)
    {
        throw new NotImplementedException();
    }
}