using EventUnion.Domain.AutomaticTransfers;

namespace EventUnion.Infrastructure.Repositories;

public class AutomaticTransferRepository(EventUnionDbContext dbContext) : IAutomaticTransferRepository
{
    public Task<AutomaticTransfer?> GetAggregateByIdAsync(Guid automaticTransferId,
        CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
    }
}