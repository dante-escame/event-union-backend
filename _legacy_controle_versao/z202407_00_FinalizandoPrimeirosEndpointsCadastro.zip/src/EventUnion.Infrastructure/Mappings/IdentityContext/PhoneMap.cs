using EventUnion.Domain.IdentityContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EventUnion.Infrastructure.Mappings.IdentityContext;

public class PhoneMap : IEntityTypeConfiguration<Phone>
{
    public void Configure(EntityTypeBuilder<Phone> builder)
    {
        builder.ToTable("Phone");
        
        builder.HasKey(p => p.UserId);
        
        builder.HasOne(p => p.User)
            .WithOne()
            .HasForeignKey<Phone>(p => p.UserId);
        
        builder.Property(p => p.Value).IsRequired().HasMaxLength(15);
    }
}