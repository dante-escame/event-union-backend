namespace EventUnion.Domain.AutomaticTransfers.Processes;

public interface IAutomaticTransferProcessRepository
{
    Task<List<AutomaticTransferProcess>> GetActiveAwaitingProcesses(DateTime now);
    Task<AutomaticTransferProcess?> GetByIdAsync(Guid automaticTransferProcessId);
}