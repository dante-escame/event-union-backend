using EventUnion.CommonResources;

namespace EventUnion.Domain.AutomaticTransfers.Processes;

public class AutomaticTransferProcess : AggregateRoot<Guid>
{
    // ReSharper disable once UnusedMember.Local
    private AutomaticTransferProcess() { }
}