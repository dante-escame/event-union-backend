namespace EventUnion.Domain.AutomaticTransfers;

public enum RecurrenceType
{
    Daily = 1,
    Weekly = 2,
    Monthly = 3
}