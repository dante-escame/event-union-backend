namespace EventUnion.Domain.AutomaticTransfers;

public interface IAutomaticTransferRepository
{
    Task<AutomaticTransfer?> GetAggregateByIdAsync(Guid automaticTransferId, CancellationToken cancellationToken);
}