using System.Globalization;
using CSharpFunctionalExtensions;
using EventUnion.CommonResources;

namespace EventUnion.Domain.AutomaticTransfers;

public class Percentage : ValueObject
{
    public const decimal MinValue = 0M;
    public const decimal MaxValue = 100M;

    private Percentage(decimal value)
    {
        Value = value;
    }

    public decimal Value { get; private set; }

    public static Result<Percentage, Error> Create(decimal? percentage)
    {
        return percentage switch
        {
            null => CommonError.ValueIsEmpty("Percentage"),
            < 0 or > 100 => CommonError.ValueIsOutOfLimits(nameof(percentage),
                MinValue.ToString(CultureInfo.InvariantCulture), MaxValue.ToString(CultureInfo.InvariantCulture)),
            _ => new Percentage(percentage.Value)
        };
    }

    protected override IEnumerable<IComparable> GetEqualityComponents()
    {
        yield return Value;
    }
}