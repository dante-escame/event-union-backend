using EventUnion.CommonResources;

namespace EventUnion.Domain.AutomaticTransfers;

public class AutomaticTransfer : AggregateRoot<Guid>
{
    // ReSharper disable once UnusedMember.Local
    private AutomaticTransfer() { }

    public AutomaticTransfer(Guid bankContactId, Percentage percentage, TimeOnly hour)
    {
        
    }

    public AutomaticTransfer(Guid bankContactId, Percentage percentage, TimeOnly hour, DayOfWeek dayOfWeek)
    {
        
    }

    public AutomaticTransfer(Guid bankContactId, Percentage percentage, TimeOnly hour, int dayOfMonth)
    {
        
    }

    public DateTime GetScheduleDate(DateTime now)
    {
        throw new NotImplementedException();
    }

    public void Activate()
    {
        throw new NotImplementedException();
    }

    public void Deactivate()
    {
        throw new NotImplementedException();
    }
}