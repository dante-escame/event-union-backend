// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable UnusedType.Global
// ReSharper disable UnusedMember.Local
// ReSharper disable UnusedMember.Global

using System.Diagnostics.CodeAnalysis;

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

namespace EventUnion.Domain.IdentityContext;

public class Address
{
    public Guid AddressId { get; private set; }
    public string ZipCode { get; private set; }
    public string Street { get; private set; }
    public string Neighborhood { get; private set; }
    public string Number { get; private set; }
    public string AdditionalInfo { get; private set; }
    public string State { get; private set; }
    public string Country { get; private set; }
    public string City { get; private set; }

    public Address(Guid addressId, string zipCode, string street, string neighborhood, 
        string number, string additionalInfo, string state, string country, string city)
    {
        AddressId = addressId;
        ZipCode = zipCode;
        Street = street;
        Neighborhood = neighborhood;
        Number = number;
        AdditionalInfo = additionalInfo;
        State = state;
        Country = country;
        City = city;
    }
    
    [ExcludeFromCodeCoverage]
    private Address() { }
}