using System.Diagnostics.CodeAnalysis;
using CSharpFunctionalExtensions;
using EventUnion.CommonResources;

namespace EventUnion.Domain.ValueObjects;

public class Version : ValueObject
{
    // ReSharper disable once AutoPropertyCanBeMadeGetOnly.Local
    public string Value { get; private set; } = null!;
    
    public static Result<Version, Error> Create(string version, string fieldName = "Version")
    {
        if (string.IsNullOrWhiteSpace(version))
            return CommonError.ValueIsEmpty(fieldName);

        if (!IsValidSemanticVersion(version))
            return CommonError.ValueIsInvalid(fieldName);

        return new Version(version);
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Value;
    }

    private static bool IsValidSemanticVersion(string version)
    {
        var versionParts = version.Split('.');

        if (versionParts.Length != 3)
            return false;

        return versionParts.ToList().TrueForAll(part => 
            int.TryParse(part, out var number) && number is >= 0 and <= 1000);
    }
    
    private Version(string value)
    {
        Value = value;
    }
    
    // EFCore Constructor
    // ReSharper disable once UnusedMember.Local
    [ExcludeFromCodeCoverage]
    private Version() { }
}