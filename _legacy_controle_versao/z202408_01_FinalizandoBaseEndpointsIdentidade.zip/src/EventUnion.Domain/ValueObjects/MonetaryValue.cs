using System.Diagnostics.CodeAnalysis;
using CSharpFunctionalExtensions;
using EventUnion.CommonResources;

namespace EventUnion.Domain.ValueObjects;

public class MonetaryValue : ValueObject
{
    // ReSharper disable once AutoPropertyCanBeMadeGetOnly.Local
    public decimal Value { get; private set; }

    // ReSharper disable once UnusedMember.Global
    public static Result<MonetaryValue, Error> Create(decimal monetaryValue, string fieldName = "MonetaryValue")
    {
        monetaryValue = Math.Round(monetaryValue, 2);

        if (monetaryValue < 0)
            return CommonError.ValueIsNegative(fieldName);
        
        return new MonetaryValue(monetaryValue);
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Value;
    }
    
    private MonetaryValue(decimal monetaryValue)
    {
        Value = monetaryValue;
    }
    
    // EFCore Constructor
    // ReSharper disable once UnusedMember.Local
    [ExcludeFromCodeCoverage]
    private MonetaryValue() { }
}