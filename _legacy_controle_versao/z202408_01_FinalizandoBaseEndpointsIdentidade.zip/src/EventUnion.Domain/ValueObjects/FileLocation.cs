using System.Diagnostics.CodeAnalysis;
using CSharpFunctionalExtensions;
using EventUnion.CommonResources;

namespace EventUnion.Domain.ValueObjects;

public class FileLocation : ValueObject
{
    // ReSharper disable once MemberCanBePrivate.Global
    public const int MaxLength = 300;
    
    // ReSharper disable once AutoPropertyCanBeMadeGetOnly.Local
    public string Value { get; private set; } = null!;
    // ReSharper disable once AutoPropertyCanBeMadeGetOnly.Local
    public PathType PathType { get; private set; }

    // ReSharper disable once UnusedMember.Global
    public static Result<FileLocation, Error> Create(string fileLocation, string fieldName = "FileLocation")
    {
        if (string.IsNullOrWhiteSpace(fileLocation))
            return CommonError.ValueIsEmpty(fieldName);

        fileLocation = fileLocation.Trim();

        if (fileLocation.Length > MaxLength)
            return CommonError.ValueIsTooLong(fieldName, MaxLength);
            
        var isUrl = Url.ContainsProtocol(fileLocation);
        
        if (!isUrl) return ValidateLocalPath(fileLocation, fieldName);
        
        var urlResult = Url.Create(fileLocation, fieldName);

        if (urlResult.IsFailure) return urlResult.Error;

        return new FileLocation(urlResult.Value.Value, PathType.Url);
    }
    
    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Value;
        yield return PathType;
    }

    private static readonly char[] InvalidPathChars = Path.GetInvalidPathChars();
    
    private static Result<FileLocation, Error> ValidateLocalPath(string fileLocation, string fieldName)
    {
        if (fileLocation.IndexOfAny(InvalidPathChars) >= 0)
            return CommonError.ValueIsInvalid(fieldName);

        if (!Path.IsPathRooted(fileLocation))
            return CommonError.ValueIsInvalid(fieldName);

        if (fileLocation.EndsWith('.'))
            return CommonError.ValueIsInvalid(fieldName);
        
        return new FileLocation(fileLocation, PathType.Local);
    }
    
    // EFCore Constructor
    // ReSharper disable once UnusedMember.Local
    [ExcludeFromCodeCoverage]
    private FileLocation () { }
    
    private FileLocation(string value, PathType pathType)
    {
        Value = value;
        PathType = pathType;
    }
}
    
public enum PathType
{
    Local = 1,
    Url = 2
}