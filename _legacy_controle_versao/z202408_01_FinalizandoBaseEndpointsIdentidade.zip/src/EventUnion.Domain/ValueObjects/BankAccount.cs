using System.Diagnostics.CodeAnalysis;
using CSharpFunctionalExtensions;
using EventUnion.CommonResources;

namespace EventUnion.Domain.ValueObjects;

// ReSharper disable once UnusedType.Global
public class BankAccount : ValueObject
{
    // ReSharper disable MemberCanBePrivate.Global
    public const int BankCodeLength = 3;
    public const int BankCodeMaxLength = 5;
    public const int BranchLength = 4;
    public const int AccountLength = 20;
    // ReSharper restore MemberCanBePrivate.Global
        
    // ReSharper disable AutoPropertyCanBeMadeGetOnly.Local 
    public string BankCode { get; private set; } = null!;
    public string Branch { get; private set; } = null!;
    public string Account { get; private set; } = null!;
        
    // ReSharper disable once UnusedMember.Global
    public static Result<BankAccount, Error> Create(string bankCode, string branch, string accountNumber)
    {
        var bankCodeResult = ValidateBankCode(bankCode);
        if (bankCodeResult.IsFailure) return bankCodeResult.Error;

        var branchResult = ValidateBranch(branch);
        if (branchResult.IsFailure) return branchResult.Error;

        var accountNumberResult = ValidateAccountNumber(accountNumber);
        if (accountNumberResult.IsFailure) return accountNumberResult.Error;

        bankCode = SanitizeBankCode(bankCode);
        branch = SanitizeBranch(branch);
        accountNumber = SanitizeAccountNumber(accountNumber);
            
        return new BankAccount(bankCode, branch, accountNumber);
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return BankCode;
        yield return Branch;
        yield return Account;
    }
        
    private static string SanitizeAccountNumber(string value) => 
        StringUtils.RemoveExtraSpaces(value);

    private static string SanitizeBranch(string branch) =>
        StringUtils.RemoveExtraSpaces(branch.Trim())
            .CompleteWithLeftZeros(4);
        
    private static string SanitizeBankCode(string bankCode) =>
        StringUtils.RemoveExtraSpaces(bankCode.Trim())
            .CompleteWithLeftZeros(3);

    // ReSharper disable once MemberCanBePrivate.Global
    public static UnitResult<Error> ValidateAccountNumber(string accountNumber, 
        string fieldName = "BankAccount.Account")
    {
        accountNumber = SanitizeAccountNumber(accountNumber);
            
        if (string.IsNullOrWhiteSpace(accountNumber))
            return CommonError.ValueIsEmpty(fieldName);
            
        return UnitResult.Success<Error>();
    }
    
    // ReSharper disable once MemberCanBePrivate.Global
    public static UnitResult<Error> ValidateBranch(string branch, string fieldName = "BankAccount.Branch")
    {
        branch = SanitizeAccountNumber(branch);
            
        if (string.IsNullOrWhiteSpace(branch))
            return CommonError.ValueIsEmpty(fieldName);

        if (!IsNumeric(branch))
            return CommonError.ValueIsNotNumeric(fieldName);

        if (IsAllZeros(branch))
            return CommonError.ValueIsInvalid(fieldName);
            
        if (branch.Length > BranchLength)
            return CommonError.ValueLengthIsInvalid(fieldName, BranchLength);

        return UnitResult.Success<Error>();
    }

    // ReSharper disable once MemberCanBePrivate.Global
    public static UnitResult<Error> ValidateBankCode(string bankCode, string fieldName = "BankAccount.BankCode")
    {
        bankCode = SanitizeAccountNumber(bankCode);
            
        if (string.IsNullOrWhiteSpace(bankCode))
            return CommonError.ValueIsEmpty(fieldName);

        if (!IsAlphanumeric(bankCode))
            return CommonError.ValueIsNotAlphanumeric(fieldName);

        if (IsAllZeros(bankCode))
            return CommonError.ValueIsInvalid(fieldName); 
            
        if (bankCode.Length is < BankCodeLength or > BankCodeMaxLength)
            return CommonError.ValueIsOutOfLimits(fieldName, 
                BankCodeLength.ToString(), BankCodeMaxLength.ToString());

        return UnitResult.Success<Error>();
    }
        
    private static bool IsAllZeros(string value) => value.All(x => x == '0');

    private static bool IsNumeric(string value) => value.All(char.IsNumber);

    private static bool IsAlphanumeric(string value) => value.Trim().All(char.IsLetterOrDigit);
        
    private BankAccount(string bankCode, string branch, string accountNumber)
    {
        BankCode = bankCode;
        Branch = branch;
        Account = accountNumber;
    }
        
    // EFCore Constructor
    // ReSharper disable once UnusedMember.Local
    [ExcludeFromCodeCoverage]
    private BankAccount() { }
}