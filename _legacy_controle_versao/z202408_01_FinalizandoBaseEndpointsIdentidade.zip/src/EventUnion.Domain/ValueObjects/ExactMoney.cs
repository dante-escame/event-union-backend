using System.Diagnostics.CodeAnalysis;
using CSharpFunctionalExtensions;
using EventUnion.CommonResources;

namespace EventUnion.Domain.ValueObjects;

public class ExactMoney : ValueObject
{
    // ReSharper disable once AutoPropertyCanBeMadeGetOnly.Local
    public decimal? Value { get; private set; }

    // ReSharper disable once UnusedMember.Global
    public static Result<ExactMoney, Error> Create(decimal value, string fieldName = "ExactMoney")
    {
        if (value < 0)
            return CommonError.ValueIsNegative(fieldName);

        value = decimal.Round(value, 4);
        
        return new ExactMoney(value);
    }
    
    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Value!;
    }
    
    private ExactMoney(decimal value)
    {
        Value = value;
    }
        
    // EFCore Constructor
    // ReSharper disable once UnusedMember.Local
    [ExcludeFromCodeCoverage]
    private ExactMoney() { }
}