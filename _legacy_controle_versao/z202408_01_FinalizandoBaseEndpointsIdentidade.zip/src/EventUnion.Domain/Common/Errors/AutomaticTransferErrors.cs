using EventUnion.CommonResources;

namespace EventUnion.Domain.Common.Errors;

public static partial class Errors
{
    public static class AutomaticTransferProcess
    {
        public static Error NoBalance()
            => new("automatic_transfer.balance.none",
                "Cannot process automatic transfer with no available balance.");

        public static Error ProcessIsFinished()
            => new("automatic_transfer.process.finished",
                "This automatic transfer process was already finished.");

        public static Error NotSent()
            => new("automatic_transfer.process.not_sent",
                "This automatic transfer process was not sent yet.");
    }

    public static class AutomaticTransfer
    {
        public static Error Disabled()
            => new("automatic_transfer.recurrence.disabled",
                "Cannot generate recurrence to a disabled automatic transfer.");

        public static Error AlreadyDisabled()
            => new("automatic_transfer.active.already_disabled",
                "Cannot disable automatic transfer that is already disabled.");


        public static Error AlreadyActive()
            => new("automatic_transfer.active.already_active",
                "Cannot activate automatic transfer that is already active.");
    }
}