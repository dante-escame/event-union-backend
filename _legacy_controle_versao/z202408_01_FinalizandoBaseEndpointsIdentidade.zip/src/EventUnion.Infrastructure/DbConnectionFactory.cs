using System.Data;
using Microsoft.Extensions.Options;
using Npgsql;
using EventUnion.Domain.Common.Interfaces;

namespace EventUnion.Infrastructure;

public class DbConnectionFactory(IOptions<ConnectionStringOptions> connectionStringsOptions)
    : IDbConnectionFactory
{
    private readonly string _connectionString = connectionStringsOptions.Value.ConnectionString!;

    public IDbConnection CreateOpenConnection()
    {
        var connection = new NpgsqlConnection(_connectionString);

        connection.Open();

        return connection;
    }
}