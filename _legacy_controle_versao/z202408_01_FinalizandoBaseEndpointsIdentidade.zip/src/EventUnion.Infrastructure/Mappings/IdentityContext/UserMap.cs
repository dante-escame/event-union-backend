using EventUnion.Domain.IdentityContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EventUnion.Infrastructure.Mappings.IdentityContext;

public class UserMap : IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> builder)
    {
        builder.ToTable("User");
        
        builder.UseTptMappingStrategy();
        
        builder.HasKey(u => u.UserId);
        
        builder.Property(u => u.Email).IsRequired().HasMaxLength(256);
        builder.Property(u => u.Password).IsRequired();
        
        builder.Property(u => u.CriptKey).IsRequired();
        builder.Property(u => u.Iv).IsRequired();
    }
}