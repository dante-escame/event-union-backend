using EventUnion.Domain.IdentityContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EventUnion.Infrastructure.Mappings.IdentityContext;

public class CompanyMap : IEntityTypeConfiguration<Company>
{
    public void Configure(EntityTypeBuilder<Company> builder)
    {
        builder.ToTable("Company");
        
        builder.Property(c => c.CompanyId).IsRequired();
        builder.Property(c => c.Cnpj).IsRequired().HasMaxLength(14);
        builder.Property(c => c.LegalName).IsRequired().HasMaxLength(256);
        builder.Property(c => c.TradeName).HasMaxLength(256);
        builder.Property(c => c.Specialization).HasMaxLength(256);
    }
}