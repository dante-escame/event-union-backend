using System.Data;
using CSharpFunctionalExtensions;
using EventUnion.CommonResources;
using EventUnion.Domain.Common.Interfaces;
using EventUnion.Domain.IdentityContext;
using EventUnion.Infrastructure;
using FastEndpoints;
using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;

// ReSharper disable UnusedType.Global
// ReSharper disable UnusedAutoPropertyAccessor.Local

namespace EventUnion.Api.Features.Users;

public static class AddAddress
{
    #region Endpoint
    
    // ReSharper disable UnusedAutoPropertyAccessor.Global
    // ReSharper disable once ClassNeverInstantiated.Global
    public class Request
    {
        public Guid UserId { get; set; }
        public AddressPayload? Address { get; set; }

        // ReSharper disable once ClassNeverInstantiated.Global
        public record AddressPayload
        {
            public string? ZipCode { get; set; }
            public string? Street { get; set; }
            public string? Neighbourhood { get; set; }
            public string? Number { get; set; }
            public string? AddInfo { get; set; }
            public string? Country { get; set; }
            public string? State { get; set; }
            public string? City { get; set; }
        }
    }
    // ReSharper restore UnusedAutoPropertyAccessor.Global

    public class RequestValidator : Validator<Request>
    {
        public RequestValidator()
        {
            RuleLevelCascadeMode = CascadeMode.Stop;

            RuleFor(x => x.UserId)
                .NotEmptyWithError();

            RuleFor(x => x.Address)
                .NotNullWithError();

            RuleFor(x => x.Address!.ZipCode)
                .NotEmptyWithError();

            RuleFor(x => x.Address!.Street)
                .NotEmptyWithError();

            RuleFor(x => x.Address!.Neighbourhood)
                .NotEmptyWithError();

            RuleFor(x => x.Address!.Number)
                .NotEmptyWithError();

            RuleFor(x => x.Address!.Country)
                .NotEmptyWithError();

            RuleFor(x => x.Address!.State)
                .NotEmptyWithError();

            RuleFor(x => x.Address!.City)
                .NotEmptyWithError();
        }
    }

    [Authorize]
    public class Endpoint(ISender sender) : Endpoint<Request, Result<ResourceLocator<Guid>, Error>>
    {
        public override void Configure()
        {
            Post("api/addresses");
            AllowAnonymous();
        }
        
        public override async Task<Result<ResourceLocator<Guid>, Error>> ExecuteAsync(Request req, CancellationToken ct)
        {
            var commandSave = new Command(
                req.UserId, 
                req.Address?.ZipCode, 
                req.Address?.Street, 
                req.Address?.Neighbourhood, 
                req.Address?.Number, 
                req.Address?.AddInfo, 
                req.Address?.Country, 
                req.Address?.State, 
                req.Address?.City);
            
            return await sender.Send(commandSave, ct);
        }
    }
    #endregion
    
    #region Handler
    public record Command(
        Guid UserId, 
        string? ZipCode, 
        string? Street, 
        string? Neighbourhood, 
        string? Number, 
        string? AddInfo, 
        string? Country, 
        string? State, 
        string? City) : IRequest<Result<ResourceLocator<Guid>, Error>>;
    
    internal class Handler(
        IUnitOfWork unitOfWork,
        EventUnionDbContext dbContext)
        : IRequestHandler<Command, Result<ResourceLocator<Guid>, Error>>
    {
        public async Task<Result<ResourceLocator<Guid>, Error>> Handle(Command request, CancellationToken ct)
        {
            var user = await dbContext.Set<User>()
                .FirstOrDefaultAsync(x => x.UserId == request.UserId,
                    cancellationToken: ct);

            if (user is not null)
            {
                var address = new Address(Guid.NewGuid(),
                    request.ZipCode ?? "", 
                    request.Street ?? "", 
                    request.Neighbourhood ?? "", 
                    request.Number ?? "", 
                    request.AddInfo ?? "", 
                    request.State ?? "", 
                    request.Country ?? "", 
                    request.City ?? "");
                await unitOfWork.AddAsync(address, ct);

                var userAddress = new UserAddress(user, address);
                await unitOfWork.AddAsync(userAddress, ct);
                
                var result = await unitOfWork.SaveChangesAsync(ct);
                if (result.IsFailure)
                    return result.Error;

                return new ResourceLocator<Guid>(address.AddressId);
            }

            throw new DataException("Informações de usuário não encontradas.");
        }
    }
    #endregion
}