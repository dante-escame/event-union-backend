// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable UnusedType.Global
// ReSharper disable UnusedMember.Local
// ReSharper disable UnusedMember.Global
// ReSharper disable ClassNeverInstantiated.Global

using System.Diagnostics.CodeAnalysis;
using EventUnion.Domain.ValueObjects;

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

namespace EventUnion.Domain.Events;

public class EventSpace
{
    public Guid EventSpaceId { get; private set; }
    public Period Period { get; private set; }
    public Event Event { get; private set; }
    public Place Place { get; private set; }

    public EventSpace(Guid eventSpaceId, Event eventObj, Place place, Period period)
    {
        EventSpaceId = eventSpaceId;
        Event = eventObj;
        Place = place;
        Period = period;
    }

    [ExcludeFromCodeCoverage]
    private EventSpace() { }
}