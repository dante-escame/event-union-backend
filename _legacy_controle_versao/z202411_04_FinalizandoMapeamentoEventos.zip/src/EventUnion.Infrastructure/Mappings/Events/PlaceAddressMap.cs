using EventUnion.Domain.Events;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EventUnion.Infrastructure.Mappings.Events;

public class PlaceAddressMap : IEntityTypeConfiguration<PlaceAddress>
{
    public void Configure(EntityTypeBuilder<PlaceAddress> builder)
    {
        builder.ToTable("PlaceAddress");

        builder.HasKey(pa => pa.PlaceAddressId);

        builder.Property(pa => pa.PlaceAddressId)
            .ValueGeneratedOnAdd()
            .IsRequired();
        
        builder.HasOne(pa => pa.Place)
            .WithMany()
            .IsRequired();

        builder.HasOne(pa => pa.Address)
            .WithMany()
            .IsRequired();
    }
}