using EventUnion.Domain.Events;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EventUnion.Infrastructure.Mappings.Events;

public class EventSpaceMap : IEntityTypeConfiguration<EventSpace>
{
    public void Configure(EntityTypeBuilder<EventSpace> builder)
    {
        builder.ToTable("EventSpace");

        builder.HasKey(es => es.EventSpaceId);

        builder.Property(es => es.EventSpaceId)
            .IsRequired();
        
        builder.OwnsOne(p => p.Period, x =>
        {
            x.Property(period => period.StartDate)
                .HasColumnName("start_date")
                .IsRequired();
            
            x.Property(period => period.EndDate)
                .HasColumnName("end_date")
                .IsRequired();
        });

        builder.HasOne(es => es.Event)
            .WithMany()
            .IsRequired();

        builder.HasOne(es => es.Place)
            .WithMany()
            .IsRequired();
    }
}