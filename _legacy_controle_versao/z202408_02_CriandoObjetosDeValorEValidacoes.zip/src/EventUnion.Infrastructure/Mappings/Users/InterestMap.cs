using EventUnion.Domain.Addresses;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EventUnion.Infrastructure.Mappings.Users;

public class InterestMap : IEntityTypeConfiguration<Interest>
{
    public void Configure(EntityTypeBuilder<Interest> builder)
    {
        builder.ToTable("Interest");
        
        builder.HasKey(i => i.InterestId);
        
        builder.HasOne(i => i.User)
            .WithMany() // A user can have multiple interests
            .HasForeignKey("User Id"); // Assuming UserId is the foreign key in Interest
    }
}