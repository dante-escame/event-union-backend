using EventUnion.Domain.Addresses;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EventUnion.Infrastructure.Mappings.Addresses;

public class AddressMap : IEntityTypeConfiguration<Address>
{
    public void Configure(EntityTypeBuilder<Address> builder)
    {
        builder.ToTable("Address");
        
        builder.HasKey(a => a.AddressId);
        
        builder.Property(a => a.ZipCode).IsRequired().HasMaxLength(10);
        builder.Property(a => a.Street).IsRequired().HasMaxLength(256);
        builder.Property(a => a.Neighborhood).HasMaxLength(256);
        builder.Property(a => a.Number).HasMaxLength(10);
        builder.Property(a => a.AdditionalInfo).HasMaxLength(256);
        builder.Property(a => a.State).IsRequired().HasMaxLength(2);
        builder.Property(a => a.Country).IsRequired().HasMaxLength(100);
    }
}