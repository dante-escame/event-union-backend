// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable UnusedType.Global
// ReSharper disable UnusedMember.Local

using System.Diagnostics.CodeAnalysis;
using EventUnion.CommonResources;

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

namespace EventUnion.Domain.Users;

public abstract class User : AggregateRoot<Guid>
{
    protected User(Guid userId, string email, string password, string criptKey, string iv)
    {
        UserId = userId;
        Email = email;
        Password = password;
        CriptKey = criptKey;
        Iv = iv;
    }
    
    public Guid UserId { get; private set; }
    public string Email { get; private set; }
    public string Password { get; private set; }
    public string CriptKey { get; private set; }
    public string Iv { get; set; }
    
    [ExcludeFromCodeCoverage]
    private User() { }
}