// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable UnusedType.Global
// ReSharper disable UnusedMember.Local

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

namespace EventUnion.Domain.Users;

public class Company : User
{
    public Guid CompanyId { get; private set; }
    public string Cnpj { get; private set; }
    public string LegalName { get; private set; }
    public string TradeName { get; private set; }
    public string Specialization { get; private set; }

    public Company(Guid userId, string email, string password, string criptKey, string iv,
        Guid companyId, string cnpj, string legalName, string tradeName, string specialization)
        : base(userId, email, password, criptKey, iv)
    {
        CompanyId = companyId;
        Cnpj = cnpj;
        LegalName = legalName;
        TradeName = tradeName;
        Specialization = specialization;
    }
}
