// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable UnusedType.Global
// ReSharper disable UnusedMember.Local
// ReSharper disable UnusedMember.Global
// ReSharper disable ClassNeverInstantiated.Global

using System.Diagnostics.CodeAnalysis;
using EventUnion.Domain.Addresses;

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

namespace EventUnion.Domain.Events;

public class PlaceAddress
{
    public Place Place { get; private set; }
    public Address Address { get; private set; }

    public PlaceAddress(Place place, Address address)
    {
        Place = place;
        Address = address;
    }

    [ExcludeFromCodeCoverage]
    private PlaceAddress() { }
}