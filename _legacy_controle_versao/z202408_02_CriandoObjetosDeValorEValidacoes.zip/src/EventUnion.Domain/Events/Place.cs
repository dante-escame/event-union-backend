// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable UnusedType.Global
// ReSharper disable UnusedMember.Local
// ReSharper disable UnusedMember.Global
// ReSharper disable ClassNeverInstantiated.Global

using System.Diagnostics.CodeAnalysis;

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

namespace EventUnion.Domain.Events;

public class Place
{
    public Guid PlaceId { get; private set; }
    public string Name { get; private set; }
    public int Capacity { get; private set; }

    public Place(Guid placeId, string name, int capacity)
    {
        PlaceId = placeId;
        Name = name;
        Capacity = capacity;
    }

    [ExcludeFromCodeCoverage]
    private Place() { }
}