# Vertical Slice Architecture Template
